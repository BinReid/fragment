from ton_fragment.numbers.numbers import Numbers
# from ton_fragment.usernames.main import collection_0
# from ton_fragment.usernames.main import collection_2
# from ton_fragment.usernames.POGGERS import collection_2
# from ton_fragment.usernames.POGGERS import collection_2
# html/body/div/main/section/div/table/tbody/tr/td/div/div
# html/body/div/main/section/div/table/tbody/tr
# https://fragment.com/numbers?sort=price_asc&filter=sale
import telebot
bot = telebot.TeleBot('7243404227:AAG2DSVxzJXTddHhS82dp1L6aj4DRbN1DKI')


# @bot.message_handler(content_types=['text'])
# def get_text_messages(message):
while True:
        num = Numbers('sale', 'price_asc')
        a = num.result
        print(a)
#       des0 = collection_0['description']
#       lin0 = collection_0['link']
#       des0 = float(des0)
#       des1 = collection_2['description']
#       des1 = float(des1)
#       des2 = des1 - des0
#       if des2 < 3:
#           des2 = 0
#         num = Numbers('sale', 'price_asc')
        # a = num.result[0]
        # a2 = num.result[2]
        # num0 = (a[0].strip("+"))
        # nu = str(num0)
        # n = int(nu.replace(" ", ""))
        # ton0 = a[1]
        # ton2 = a2[1]
        # b = int(ton2) - int(ton0)
        # print(num)
        # if b < 3:
        #     b = 0
        #     if b < des2:
        #         c = f"Лот https://fragment.com/number/{n} "
        #         bot.send_message(message.from_user.id, str(c))
        #     elif b > des2:
        #         bot.send_message(message.from_user.id, str(lin0))
        #     elif b == des2 == 0:
        #         pass
        #     elif b == des2 != 0:
        #         bot.send_message(message.from_user.id, str(lin0))
        #         c = f"Лот https://fragment.com/number/{n} "
        #         bot.send_message(message.from_user.id, str(c))
        #         bot.send_message(message.from_user.id, str("бери где хочешь, цена одна"))
        #     else:
        #         bot.send_message(message.from_user.id, str("ничего не бери"))


# bot.polling(none_stop=True, interval=0)

