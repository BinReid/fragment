while True:
    a = 1
    while a == 1:
        from ton_fragment.usernames.POGGERSs import p
        from ton_fragment.usernames.POGGERSs import plin0
        from ton_fragment.usernames.mains import m
        from ton_fragment.usernames.mains import mlin0
        from ton_fragment.usernames.CRAKERSs import c
        from ton_fragment.usernames.CRAKERSs import clin0
        from ton_fragment.usernames.Areyouwiningsons import a
        from ton_fragment.usernames.Areyouwiningsons import alin0
        import telebot
        bot = telebot.TeleBot('7243404227:AAH-XGIuTycDP0p4Cys9RlkEt_IKoLmOcBQ')


        @bot.message_handler(commands=['start'])
        def get_text_messages(message):
            bot.send_message(message.from_user.id, str("Привет, с этого момента программа работает"))
            while True:
                if p == 0:
                    pass
                    if m == 0:
                        pass
                        if c == 0:
                            pass
                            if a == 0:
                                pass
                            elif a != 0:
                                bot.send_message(message.from_user.id, str(alin0))
                        else:
                            if a == 0:
                                bot.send_message(message.from_user.id, str(clin0))
                            elif a != 0 and c != 0:
                                bot.send_message(message.from_user.id, str(clin0))
                                bot.send_message(message.from_user.id, str(alin0))
                            else:
                                pass
                    else:
                        if c == 0 and a == 0:
                            bot.send_message(message.from_user.id, str(mlin0))
                        elif c != 0 and a == 0:
                            bot.send_message(message.from_user.id, str(mlin0))
                            bot.send_message(message.from_user.id, str(clin0))
                        elif c == 0 and a != 0:
                            bot.send_message(message.from_user.id, str(mlin0))
                            bot.send_message(message.from_user.id, str(alin0))
                        elif m != 0 and c != 0 and a != 0:
                            bot.send_message(message.from_user.id, str(mlin0))
                            bot.send_message(message.from_user.id, str(clin0))
                            bot.send_message(message.from_user.id, str(alin0))
                        else:
                            pass
                else:
                    if m == 0 and c == 0 and a == 0:
                        bot.send_message(message.from_user.id, str(plin0))
                    elif m != 0 and c == 0 and a == 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(mlin0))
                    elif m == 0 and c != 0 and a == 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(clin0))
                    elif m == 0 and c == 0 and a != 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(alin0))
                    elif m != 0 and c != 0 and a == 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(mlin0))
                        bot.send_message(message.from_user.id, str(clin0))
                    elif m == 0 and c != 0 and a != 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(clin0))
                        bot.send_message(message.from_user.id, str(alin0))
                    elif m != 0 and c == 0 and a != 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(mlin0))
                        bot.send_message(message.from_user.id, str(alin0))
                    elif p != 0 and m != 0 and c != 0 and a != 0:
                        bot.send_message(message.from_user.id, str(plin0))
                        bot.send_message(message.from_user.id, str(mlin0))
                        bot.send_message(message.from_user.id, str(clin0))
                        bot.send_message(message.from_user.id, str(alin0))
                    else:
                        pass


        bot.polling(none_stop=True, interval=0)
        a = a + 0
