from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.chrome.options import Options
import time
import re

options = Options()
options.add_argument("--headless=new")  # Запускать браузер в фоновом режиме
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--disable-gpu')
options.add_argument('--disable-application-cache')
options.add_argument('--ignore-certificate-errors')
options.add_argument('--blink-settings=imagesEnabled=false')
options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
options.add_experimental_option('useAutomationExtension', False)
options.add_argument("--disable-blink-features=AutomationControlled")
driver = webdriver.Chrome(options=options)
url = 'https://xrare.io/collection/EQAOQdwdw8kGftJCSFgOErM1mBjYPe4DBPq8-\
AhF6vr9si5N?currency=TON&search=&toPrice=&fromPrice=&sort=price_low&sale=yes'
driver.get(url)

time.sleep(4)

# Найти все коллекции на странице
elements = driver.find_elements(By.XPATH, '/html/body/div[1]/main/div/div[2]/div[4]/div')

# Переменные для хранения данных коллекций 0 и 2
collection_0 = {}
collection_2 = {}

# Обработка элемента 0
try:
    if len(elements) > 0:
        element_0 = elements[0]
        collection_link_element_0 = element_0.find_element(By.TAG_NAME, "a")
        collection_link_0 = collection_link_element_0.get_attribute('href')
        collection_0 = {
            'link': collection_link_0
        }
    else:
        print("Element 0 not found.")
except Exception as e:
    print(f"Error occurred while processing element 0: {e}")

# Обработка элемента 2
try:
    if len(elements) > 2:
        element_2 = elements[2]
        collection_link_element_2 = element_2.find_element(By.TAG_NAME, "a")
        collection_link_2 = collection_link_element_2.get_attribute('href')
        collection_2 = {
            'link': collection_link_2
        }
    else:
        print("Element 2 not found.")
except Exception as e:
    print(f"Error occurred while processing element 2: {e}")


# Функция для получения данных коллекции
def fetch_collection_data(collection):
    driver.get(collection['link'])
    try:
        description_element = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, '/html/body/div[1]/main/div/div[2]/div[3]/a/span'))
        )
        collection['description'] = description_element.text
    except Exception as e:
        collection['description'] = ""
        print(f"Error occurred while getting collection description: {e}")


# Получение данных для коллекций 0 и 2
if collection_0:
    fetch_collection_data(collection_0)

if collection_2:
    fetch_collection_data(collection_2)


def filter_description(description):
    numbers = re.findall(r'\d+\.?\d*', description)  # Найти все числа, включая десятичные
    return ' '.join(numbers)


# Вывод данных
if 'description' in collection_0:
    des0 = filter_description(collection_0['description'])
    lin0 = collection_0['link']
    print(des0)
    print(lin0)

if 'description' in collection_2:
    des1 = filter_description(collection_2['description'])
    print(des1)

driver.close()
driver.quit()
