from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.chrome.options import Options
import time

options = Options()
options.add_argument("--window-size=1920,1080")  # Задать размер окна
options.add_argument('--headless')  # Запускать браузер в фоновом режиме
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--disable-gpu')
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36")
options.add_argument('--disable-application-cache')
options.add_argument('--ignore-certificate-errors')
options.add_argument('--blink-settings=imagesEnabled=false')
options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
options.add_experimental_option('useAutomationExtension', False)
options.add_argument("--disable-blink-features=AutomationControlled")
driver = webdriver.Chrome(options=options)
url = 'https://fragment.com/numbers?sort=price_asc&filter=sale'
driver.get(url)

time.sleep(3)

# Найти все коллекции на странице
elements = driver.find_elements(By.XPATH, '/html/body/div[2]/main/section[2]/div[2]/table/tbody/tr')

# Переменные для хранения данных коллекций 0 и 2
collection_0 = {}
collection_2 = {}

# Обработка элемента 0
try:
    if len(elements) > 0:
        element_0 = elements[0]
        collection_link_element_0 = element_0.find_element(By.TAG_NAME, "a")
        collection_link_0 = collection_link_element_0.get_attribute('href')
        collection_0 = {
            'link': collection_link_0
        }
    else:
        print("Element 0 not found.")
except Exception as e:
    print(f"Error occurred while processing element 0: {e}")

# Обработка элемента 2
try:
    if len(elements) > 2:
        element_2 = elements[2]
        collection_link_element_2 = element_2.find_element(By.TAG_NAME, "a")
        collection_link_2 = collection_link_element_2.get_attribute('href')
        collection_2 = {
            'link': collection_link_2
        }
    else:
        print("Element 2 not found.")
except Exception as e:
    print(f"Error occurred while processing element 2: {e}")


# Функция для получения данных коллекции
def fetch_collection_data(collection):
    driver.get(collection['link'])
    try:
        description_element = WebDriverWait(driver, 10).until(
            ec.presence_of_element_located((By.XPATH, '/html/body/div[2]/main/section[1]/div[2]/table/tbody/tr/td[1]/div/div'))
        )
        collection['description'] = description_element.text
    except Exception as e:
        collection['description'] = ""
        print(f"Error occurred while getting collection description: {e}")


# Получение данных для коллекций 0 и 2
if collection_0:
    fetch_collection_data(collection_0)

if collection_2:
    fetch_collection_data(collection_2)

# Вывод данных
if 'description' in collection_0:
    des0 = collection_0['description']
    lin0 = collection_0['link']
    print(des0)
    print(lin0)

if 'description' in collection_2:
    des1 = collection_2['description']
    print(des1)

driver.close()
driver.quit()
